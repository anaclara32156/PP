$(document).ready(function(){
	$('#cpf').mask('999.999.999-99');
});

$("#formulario").submit(function() {
	if ($('#formulario').valid()){
		$("#cpf").unmask();
	}
});

$("#formulario").validate(
	{
		rules:{
			nome:{
				required:true
			},
			dataNascimento:{
				required:true
			},
			cpf:{
				required:true,
				// remote: {
				// 	url: "clienteVerificarCPF.php",
				// 	type: "post",
				// 	data: {
				// 		id: function() {
				// 			return $("#id").val();
				// 	  	}
				// 	}
				// }		   
			},
			sexo:{
				required:true
			},
			email:{
				required:true,
				email: true,
				// remote: {
				// 	url: "clienteVerificarEmail.php",
				// 	type: "post",
				// 	data: {
				// 		id: function() {
				// 			return $("#id").val();
				// 	  	}
				// 	}
				// }		   
			},	
            tel:{
				required:true
			},					
		}, 
		messages:{
			nome:{
				required:"Campo obrigatório"
			},
			dataNascimento:{
				required:"Campo obrigatório"
			},
			cpf:{
				required:"Campo obrigatório",
				remote:"O CPF informado já existe"
			},
			sexo:{
				required:"Campo obrigatório"
			},
			email:{
				required:"Campo obrigatório",
				remote:"O e-mail informado já existe"
			},
            tel:{
				required:"Campo obrigatório"
			},				   
		}
	}
);
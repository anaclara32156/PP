<?php
session_start();
include_once "clienteCRUD.php";
$dadosUsuario = $_SESSION['dadosUsuario'];

$id = $_POST['id'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$dataNascimento = $_POST['dataNascimento'];
$sexo = $_POST['sexo'];
$tel = $_POST['tel'];
$idUsuario = $dadosUsuario['id'];
echo "<pre>";
                print_r($id);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($nome);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($email);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($cpf);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($dataNascimento);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($sexo);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($tel);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";
                echo "<pre>";
                print_r($idUsuario);  // Este seria o equivalente a console.log no PHP
                echo "</pre>";

$resultado = salvarCliente($id, $nome, $cpf, $email, $dataNascimento, $sexo, $tel, $idUsuario);

if($resultado){
    echo "<script>alert('Registro salvo com sucesso!');</script>";
    echo "<script>window.location.replace('index.php');</script>";
} else {
    echo "<script>alert('Erro ao salvar o registro');</script>";
    echo "<script>window.location.replace('clienteFormulario.php');</script>";
}
?>

<?php

	function armazenarArquivo($arquivo){
        $nomeArquivo = $arquivo["name"];
		$tamanhoArquivo = $arquivo["size"];
        $extensaoArquivo = pathinfo($nomeArquivo, PATHINFO_EXTENSION);

		if((($extensaoArquivo == "jpg") || ($extensaoArquivo == "jpeg") || ($extensaoArquivo == "png")) && $tamanhoArquivo < 100000){
			$caminhoArquivo = 
				"imagens/" . 
				md5(uniqid(rand(), true)) .
				".". 
				$extensaoArquivo;
			move_uploaded_file($arquivo["tmp_name"], $caminhoArquivo );
			return $caminhoArquivo;
		}else{
			echo  "<script>alert('Formato ou tamanho do arquivo inválido.');</script>";
		}
    }

	function criarArquivoErro($erro){
        echo "<script>alert('Foi gerada uma exceção.');</script>"; 
        date_default_timezone_set('America/Sao_Paulo');
        $data = date('d/m/Y H:i:s');
        $nomeArquivo = "erro-". date('d_m_Y-H_i_s').".txt";
        $arquivo = fopen($nomeArquivo,'a+');
        $texto = "Data: {$data} \n";
        $texto = $texto . "\t Arquivo: {$erro->getFile()} - Linha: {$erro->getLine()} \n"; 
        $texto = $texto . "\t Erro: {$erro->getMessage()} \n";
        fwrite($arquivo, $texto);
        fclose($arquivo);
    } 

    function converterDataBrasil($data){
		$retorno = "";
		if($data){
			$dataTemp = new DateTime($data);
			$retorno = $dataTemp->format('d-m-Y');
		}        
		return $retorno;
    }	
	
    /*
	 calcula a data de término somando N parcelas (meses) a data inicial
	 https://www.php.net/manual/pt_BR/class.dateinterval.php
	 outra forma
	 https://pt.stackoverflow.com/questions/264377/somar-uma-data-e-um-n%C3%BAmero-x-de-meses
	*/
    function somarMesData($data, $meses){
        $dataTemp = new DateTime($data);
		$dataTemp = $dataTemp->add(new DateInterval('P'.$meses.'M'));
		return $dataTemp->format('Y-m-d');
    }	

		/*
	https://www.jonathanmoreira.com.br/aula/como-formatar-cpf-e-cnpj-com-php.html
	*/
	
	function formatar_cpf_cnpj($documento) {
 
        $documento = preg_replace("/[^0-9]/", "", $documento);
        $qtd = strlen($documento);
 
        if($qtd >= 11) {
 
            if($qtd === 11 ) {
 
                $documentoFormatado = substr($documento, 0, 3) . '.' .
                                substr($documento, 3, 3) . '.' .
                                substr($documento, 6, 3) . '.' .
                                substr($documento, 9, 2);
            } else {
                $documentoFormatado = substr($documento, 0, 2) . '.' .
                                substr($documento, 2, 3) . '.' .
                                substr($documento, 5, 3) . '/' .
                                substr($documento, 8, 4) . '-' .
                                substr($documento, -2);
            }
 
            return $documentoFormatado;
 
        } else {
            return 'documentoumento invalido';
        }
    }		


    ?>